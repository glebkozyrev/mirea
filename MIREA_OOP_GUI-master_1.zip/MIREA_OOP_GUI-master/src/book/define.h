#pragma once

#include <vector>
#include <QMap>
#include <QString>
#include <QMainWindow>



#define _vec std::vector
#define _qmap QMap
#define _qstr QString

